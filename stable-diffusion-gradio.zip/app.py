import torch
from diffusers import StableDiffusionPipeline
import gradio as gr

pipe = StableDiffusionPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    torch_dtype=torch.float32
).to("cpu")

def generate_image(prompt):
    image = pipe(prompt).images[0]
    return image

interface = gr.Interface(
    fn=generate_image,
    inputs=gr.Textbox(label="Enter your prompt"),
    outputs=gr.Image(type="pil"),
    title="Text-to-Image Generator",
    description="Lightweight Stable Diffusion (v1-5) running on Render"
)

interface.launch(server_name="0.0.0.0", server_port=8080)